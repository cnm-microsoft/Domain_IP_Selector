import os
import json
import logging
import requests
import yaml
from pathlib import Path
from datetime import datetime

# --- 配置 ---
# 日志配置
def setup_logging():
    """配置日志记录，同时输出到控制台和文件"""
    log_dir = BASE_DIR / 'logs'
    log_dir.mkdir(exist_ok=True)
    log_file = log_dir / f"update_dns_{datetime.now().strftime('%Y-%m-%d')}.log"

    # 获取根日志记录器
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    # 如果已经有处理器，则先移除，防止重复添加
    if logger.hasHandlers():
        logger.handlers.clear()

    # 创建文件处理器
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)

    # 创建控制台处理器
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(stream_handler)

# 基础路径
BASE_DIR = Path(__file__).resolve().parent

# 初始化日志
setup_logging()

# 配置文件路径
CONFIG_FILE = BASE_DIR / 'cf_ddns_config.yaml'  # 避免文件名冲突

# IP 数据文件路径
IPV4_FILE = BASE_DIR / 'result_ipv4.json'
IPV6_FILE = BASE_DIR / 'result_ipv6.json'

# Cloudflare API 端点
CF_API_ENDPOINT = 'https://api.cloudflare.com/client/v4'

def generate_default_config():
    """生成一个包含详细说明的默认YAML配置文件"""
    config_content = """
# 这是一个Cloudflare DNS记录更新器的配置文件。
# 您可以在此文件中配置一个或多个Cloudflare账户。

# 这是一个账户列表。您可以复制整个块（从'- name:'开始）来添加更多账户。
- name: "账户1 (主账户 - IPv4)"
  # 您的Cloudflare API令牌。必须具有编辑DNS的权限。
  api_token: "YOUR_CLOUDFLARE_API_TOKEN_1"
  # 您的Zone ID。获取方法：登录Cloudflare -> 点击域名 -> 在“概述”页面右侧找到“区域 ID”。
  zone_id: "YOUR_ZONE_ID_1"
  # 指定此账户使用的IP类型: 'ipv4' 或 'ipv6'。
  # 'ipv4' 将更新A记录, 'ipv6' 将更新AAAA记录。
  ip_type: "ipv4"
  # 区域化域名配置
  region_config:
    # 键是区域代码，与您的IP数据文件中的'Region'字段对应。
    # 例如: "Asia Pacific", "North America", "Europe"
    # 值是该区域要更新的域名列表。
    # 脚本会按顺序将该区域内下载速度最快的IP分配给这些域名。
    "Asia Pacific":
      - "ap.yourdomain1.com"
      - "ap2.yourdomain1.com"
    "North America":
      - "na.yourdomain1.com"
    "Europe":
      - "eu.yourdomain1.com"

- name: "账户2 (备用账户 - IPv6)"
  api_token: "YOUR_CLOUDFLARE_API_TOKEN_2"
  # 您的Zone ID。获取方法：登录Cloudflare -> 点击域名 -> 在“概述”页面右侧找到“区域 ID”。
  zone_id: "YOUR_ZONE_ID_2"
  ip_type: "ipv6"
  region_config:
    "Asia Pacific":
      - "ap.yourdomain2.com"
    "North America":
      - "na.yourdomain2.com"
"""
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            f.write(config_content.strip())
        logging.info(f"已生成默认配置文件: {CONFIG_FILE}")
        logging.info("请修改配置文件中的信息，然后重新运行脚本。")
        return True
    except Exception as e:
        logging.error(f"生成默认配置文件失败: {e}")
        return False


def load_config():
    """加载YAML配置文件，如果不存在则创建"""
    if not CONFIG_FILE.exists():
        logging.warning(f"配置文件 {CONFIG_FILE} 不存在。正在为您生成一个默认配置...")
        if generate_default_config():
            return None
        else:
            return None

    try:
        with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    except yaml.YAMLError as e:
        logging.error(f"配置文件 {CONFIG_FILE} 格式错误。请检查YAML语法。错误: {e}")
        return None
    except Exception as e:
        logging.error(f"读取配置文件时发生错误: {e}")
        return None

def load_ip_data(ip_type='ipv4'):
    """加载优选IP数据"""
    ip_file = IPV4_FILE if ip_type == 'ipv4' else IPV6_FILE
    if not ip_file.exists():
        logging.warning(f"IP 数据文件 {ip_file} 不存在。")
        return None
    try:
        with open(ip_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    except json.JSONDecodeError:
        logging.error(f"IP 数据文件 {ip_file} 格式错误。")
        return None
    except Exception as e:
        logging.error(f"读取 IP 数据文件时发生错误: {e}")
        return None

def get_dns_record(session, zone_id, domain_name, record_type='A'):
    """获取指定域名的DNS记录"""
    url = f"{CF_API_ENDPOINT}/zones/{zone_id}/dns_records?type={record_type}&name={domain_name}"
    try:
        response = session.get(url)
        response.raise_for_status()
        records = response.json().get('result', [])
        if not records:
            logging.warning(f"未找到域名 {domain_name} 的 {record_type} 记录。")
            return None
        return records[0]
    except requests.exceptions.RequestException as e:
        logging.error(f"获取域名 {domain_name} 的DNS记录失败: {e}")
        return None
    except Exception as e:
        logging.error(f"处理域名 {domain_name} 的DNS记录时发生未知错误: {e}")
        return None


def update_dns_record(session, zone_id, record_id, record_type, domain_name, ip):
    """更新DNS记录"""
    url = f"{CF_API_ENDPOINT}/zones/{zone_id}/dns_records/{record_id}"
    data = {
        'type': record_type,
        'name': domain_name,
        'content': ip,
        'ttl': 60,
        'proxied': False
    }
    try:
        response = session.put(url, json=data)
        response.raise_for_status()
        logging.info(f"成功更新域名 {domain_name} 的 {record_type} 记录为: {ip}")
        return {'domain': domain_name, 'ip': ip}
    except requests.exceptions.RequestException as e:
        logging.error(f"更新域名 {domain_name} 的DNS记录失败: {e}")
        if e.response:
            logging.error(f"错误详情: {e.response.text}")
        return None

def process_account(account_config, all_ips):
    """处理单个账户的DNS更新逻辑"""
    updated_records = []
    api_token = account_config.get('api_token')
    zone_id = account_config.get('zone_id')
    region_config = account_config.get('region_config')
    account_name = account_config.get('name', '未命名账户')
    ip_type_to_use = account_config.get('ip_type', 'ipv4').lower()
    record_type = 'A' if ip_type_to_use == 'ipv4' else 'AAAA'

    if not all([api_token, zone_id, region_config]) or "YOUR_CLOUDFLARE_API_TOKEN" in api_token:
        logging.error(f"账户 '{account_name}' 配置不完整或仍使用默认值，已跳过。")
        return updated_records

    logging.info(f"--- 开始处理账户: {account_name} ---")

    ips_by_region = {}
    for ip_info in all_ips:
        # 使用新的键名 'Region'
        region = ip_info.get('Region')
        if region:
            if region not in ips_by_region:
                ips_by_region[region] = []
            ips_by_region[region].append(ip_info)

    for region in ips_by_region:
        # 使用新的键名 'DownloadSpeedMBps'
        ips_by_region[region].sort(key=lambda x: x.get('DownloadSpeedMBps', 0), reverse=True)

    with requests.Session() as session:
        session.headers.update({
            "Authorization": f"Bearer {api_token}",
            "Content-Type": "application/json"
        })

        for region, domains in region_config.items():
            if not isinstance(domains, list):
                logging.warning(f"区域 '{region}' 的配置不是一个域名列表，跳过。")
                continue

            regional_ips = ips_by_region.get(region)
            if not regional_ips:
                logging.warning(f"区域 '{region}' 没有可用的优选IP，跳过。")
                continue
            
            # 使用新的键名 'Address'
            regional_ip_addresses = [item['Address'] for item in regional_ips]

            for i, domain in enumerate(domains):
                if i >= len(regional_ip_addresses):
                    logging.warning(f"区域 '{region}' 的IP数量不足，域名 '{domain}' 及之后域名无法分配IP。")
                    break
                
                ip_to_set = regional_ip_addresses[i]
                logging.info(f"为域名 {domain} 分配区域 '{region}' 的IP: {ip_to_set}")

                record = get_dns_record(session, zone_id, domain, record_type)
                if record:
                    if record.get('content') != ip_to_set:
                        update_result = update_dns_record(session, zone_id, record['id'], record_type, domain, ip_to_set)
                        if update_result:
                            updated_records.append(update_result)
                    else:
                        logging.info(f"域名 {domain} 的IP已经是 {ip_to_set}，无需更新。")
    return updated_records

def main():
    """主函数"""
    logging.info("--- DNS更新脚本启动 ---")
    all_updated_records = []
    
    configs = load_config()
    if not configs:
        logging.error("无法加载配置，脚本终止。")
        return

    if not isinstance(configs, list):
        logging.error("配置文件根元素必须是一个列表，每个列表项代表一个账户配置。")
        return
        
    ipv4_ips = load_ip_data('ipv4') or []
    ipv6_ips = load_ip_data('ipv6') or []

    for account_config in configs:
        ip_type = account_config.get('ip_type', 'ipv4').lower()
        ips_to_use = ipv4_ips if ip_type == 'ipv4' else ipv6_ips
        
        if not ips_to_use:
            logging.warning(f"账户 '{account_config.get('name', '未命名')}' 需要的 {ip_type.upper()} IP数据为空，跳过此账户。")
            continue
            
        updated_for_account = process_account(account_config, ips_to_use)
        if updated_for_account:
            all_updated_records.extend(updated_for_account)

    logging.info("--- 所有账户处理完毕 ---")
    if all_updated_records:
        summary = "\n--- 本次运行更新摘要 ---\n"
        for record in all_updated_records:
            summary += f"  - 域名: {record['domain']}, 新 IP: {record['ip']}\n"
        summary += "--------------------------\n"
        logging.info(summary)
    else:
        logging.info("本次运行没有更新任何DNS记录。")
    
    logging.info("--- DNS更新脚本结束 ---")

if __name__ == '__main__':
    main()